package com.example.mobilodev;
import java.util.ArrayList;

public class Insan implements  java.io.Serializable {


    String userid;
    String parola;

    String isim;
    String cinsiyet;
    String mod;
    String yas;
    String boy;
    String kilo;
    String foto;

    ArrayList<String> notlar ;

    public Insan(){

    }
}
